# COS375 Project 2

### Group (work in groups of 2, 3, or 4 people, adjust the number of lines as needed)

- [name_1 - netid_1: email_1]
- [name_2 - netid_2: email_2]
- [name_3 - netid_3: email_3]
- [name_4 - netid_4: email_4]

## Time Investment

### Approximately how many hours did it take you to complete this assignment?

- Number of hours: [n hours]

### How many additional test cases did you write to test your implementation?

- Number of test cases: [n tests]

## Challenges Encountered

### Did you encounter any serious problems? If yes, please describe (e.g spec was unclear).

- [Yes/No]
- [If yes, please describe the problems encountered]

## Additional Comments

### Write any other comments here.

- [comment_1]
- [comment_2]

### If you decided to experiment with some more advanced branch prediction policies, describe them below.

- [descriptions]
- [findings]

## Help Information

## Generative AI.

- If you used generative AI for help with this project, please describe which one and what prompt you used.
- Refer to the syllabus generative AI tools policy: the policy for use of AI assistants parallels that for human collaboration. Remember that you cannot directly generate code that you submit. 
- Write "N/A" if you did not use generative AI for any help during this project.

- [describe how you used generate AI or N/A]

## Acknowledgement of Original Work

### Write and sign the following student acknowledgment of original work.

> For your signature, type /s/, followed by your name.
> 
> Here is an example:
>
>> This programming assignment represents my own work in accordance with University regulations and the course syllabus.  /s/ Ada Lovelace

- [Acknowledgement of student 1]
- [Acknowledgement of student 2]
- [Acknowledgement of student 3]
- [Acknowledgement of student 4]
